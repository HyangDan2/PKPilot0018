Sigrún — Portable Build (HD2Lab)
==========================================

This folder carries the portable build of HD2Lab Sigrún (pkpilot0018), the
pure-browser statistical and quality workspace.

  sigrun-portable.html    the entire application in one file

How to run it
-------------
1. Copy sigrun-portable.html anywhere on your machine.
2. Double-click it, or drag it into Microsoft Edge or Google Chrome.

That is all. There is nothing to install: no Node.js, no Python, no server,
and no network connection. Every statistic, chart and export is computed in
the browser tab itself, exactly as on the hosted build.

What works offline
------------------
* Worksheets: import CSV / XLSX, export CSV / XLSX
* Statistics: descriptive statistics, t-tests, ANOVA + Tukey, regression,
  GLM, control charts (Nelson rules), capability, Pareto, reliability,
  Gage R&R, power and sample size, DOE/RSM
* Charts: every Stage 1–3 chart, 3D surface (WebGL, with a static fallback
  when WebGL is unavailable), overlaid contour, prediction profiler,
  multi-response optimizer, graph layout editor
* Projects: Save Project writes a .sigrun.json file, Open Project reads it
  back — both through the browser's own download / file picker

Notes
-----
* The portable page has one origin (file://). Autosave uses IndexedDB where
  the browser allows it on file:// and falls back to localStorage otherwise;
  if the browser blocks both, autosave is skipped and Save Project still works.
* Browsers differ in how much they allow a file:// page to keep. For a
  long-lived installation, keep the HTML file somewhere stable rather than in
  a temporary folder.

Build information
-----------------
version     1.0.0
edition     public
generated   2026-11-25T23:09:36.000Z
size        1712421 bytes
sha256      6b43b20816ff6e11e1eae5caad11262506a8ba1a312d1fbd4f8b2fbe8838b86a

© HD2Lab
